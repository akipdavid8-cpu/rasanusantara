import { FormEvent, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { CATEGORIES, Category, Difficulty, Recipe } from "@/data/recipes";
import { useUserRecipes } from "@/hooks/useLocalRecipes";

const PLACEHOLDER_IMG =
  "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800";

export default function Submit() {
  const navigate = useNavigate();
  const { add } = useUserRecipes();

  const [title, setTitle] = useState("");
  const [origin, setOrigin] = useState("");
  const [category, setCategory] = useState<Category>("Nasi");
  const [difficulty, setDifficulty] = useState<Difficulty>("Mudah");
  const [time, setTime] = useState(30);
  const [servings, setServings] = useState(2);
  const [image, setImage] = useState("");
  const [ingredients, setIngredients] = useState("");
  const [steps, setSteps] = useState("");
  const [tips, setTips] = useState("");

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !ingredients.trim() || !steps.trim()) {
      toast({ title: "Lengkapi data resep", description: "Judul, bahan, dan langkah wajib diisi." });
      return;
    }
    const id = `user-${Date.now()}`;
    const recipe: Recipe = {
      id,
      title: title.trim(),
      origin: origin.trim() || "Nusantara",
      category,
      difficulty,
      time: Number(time) || 30,
      servings: Number(servings) || 2,
      image: image.trim() || PLACEHOLDER_IMG,
      description: `Resep ${title} dari ${origin || "Nusantara"} kiriman pengguna.`,
      ingredients: ingredients.split("\n").map((s) => s.trim()).filter(Boolean),
      steps: steps.split("\n").map((s) => s.trim()).filter(Boolean),
      tips: tips.split("\n").map((s) => s.trim()).filter(Boolean),
      nutrition: "Informasi nutrisi belum tersedia",
    };
    add(recipe);
    toast({ title: "Resep dipublikasikan!", description: `${title} berhasil ditambahkan.` });
    navigate(`/recipe/${id}`);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <section className="container mx-auto px-4 py-10 max-w-3xl flex-1 w-full">
        <div className="mb-8">
          <p className="text-xs uppercase tracking-widest text-primary font-semibold mb-1">
            Bagikan resep Anda
          </p>
          <h1 className="font-display text-3xl md:text-4xl font-extrabold">Kirim Resep Baru</h1>
          <p className="text-muted-foreground mt-2">
            Lestarikan warisan kuliner Indonesia dengan membagikan resep keluarga Anda.
          </p>
        </div>

        <form onSubmit={onSubmit} className="bg-card rounded-2xl shadow-card p-6 md:p-8 space-y-5">
          <div className="grid md:grid-cols-2 gap-4">
            <Field label="Nama Resep *">
              <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="mis. Ayam Geprek" />
            </Field>
            <Field label="Asal Daerah">
              <Input value={origin} onChange={(e) => setOrigin(e.target.value)} placeholder="mis. Yogyakarta" />
            </Field>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <Field label="Kategori">
              <Select value={category} onValueChange={(v) => setCategory(v as Category)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => (
                    <SelectItem key={c.value} value={c.value}>{c.emoji} {c.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Tingkat Kesulitan">
              <Select value={difficulty} onValueChange={(v) => setDifficulty(v as Difficulty)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Mudah">Mudah</SelectItem>
                  <SelectItem value="Sedang">Sedang</SelectItem>
                  <SelectItem value="Sulit">Sulit</SelectItem>
                </SelectContent>
              </Select>
            </Field>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <Field label="Waktu Memasak (menit)">
              <Input type="number" min={1} value={time} onChange={(e) => setTime(+e.target.value)} />
            </Field>
            <Field label="Porsi">
              <Input type="number" min={1} value={servings} onChange={(e) => setServings(+e.target.value)} />
            </Field>
          </div>

          <Field label="URL Gambar">
            <Input value={image} onChange={(e) => setImage(e.target.value)} placeholder="https://..." />
          </Field>

          <Field label="Bahan-bahan * (satu per baris)">
            <Textarea
              rows={6}
              value={ingredients}
              onChange={(e) => setIngredients(e.target.value)}
              placeholder={"500 gr daging ayam\n3 siung bawang putih\n..."}
            />
          </Field>

          <Field label="Langkah-langkah * (satu per baris)">
            <Textarea
              rows={6}
              value={steps}
              onChange={(e) => setSteps(e.target.value)}
              placeholder={"Cuci bersih ayam\nHaluskan bumbu\n..."}
            />
          </Field>

          <Field label="Tips (opsional, satu per baris)">
            <Textarea
              rows={3}
              value={tips}
              onChange={(e) => setTips(e.target.value)}
              placeholder={"Gunakan ayam kampung\nMasak dengan api kecil"}
            />
          </Field>

          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <Button type="submit" className="bg-gradient-warm shadow-warm flex-1">
              Publikasikan Resep
            </Button>
            <Button type="button" variant="outline" onClick={() => navigate(-1)}>
              Batal
            </Button>
          </div>
        </form>
      </section>
      <Footer />
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-sm font-semibold">{label}</Label>
      {children}
    </div>
  );
}
