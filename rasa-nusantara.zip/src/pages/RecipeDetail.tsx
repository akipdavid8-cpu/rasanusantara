import { Link, useParams } from "react-router-dom";
import { ArrowLeft, Clock, Flame, MapPin, Users, Heart, Lightbulb, Apple } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import EmptyState from "@/components/EmptyState";
import { Button } from "@/components/ui/button";
import { useAllRecipes, useFavorites } from "@/hooks/useLocalRecipes";
import { cn } from "@/lib/utils";

export default function RecipeDetail() {
  const { id } = useParams();
  const recipes = useAllRecipes();
  const recipe = recipes.find((r) => r.id === id);
  const { isFavorite, toggle } = useFavorites();

  if (!recipe) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="container mx-auto px-4 py-16 flex-1">
          <EmptyState
            title="Resep tidak ditemukan"
            description="Resep yang Anda cari tidak tersedia."
            action={
              <Button asChild>
                <Link to="/">Kembali ke beranda</Link>
              </Button>
            }
          />
        </div>
        <Footer />
      </div>
    );
  }

  const fav = isFavorite(recipe.id);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      {/* Hero */}
      <section className="relative">
        <div className="relative aspect-[16/9] md:aspect-[21/9] overflow-hidden">
          <img src={recipe.image} alt={recipe.title} className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-foreground/85 via-foreground/30 to-transparent" />
        </div>

        <div className="container mx-auto px-4 -mt-24 md:-mt-32 relative">
          <Link
            to="/"
            className="inline-flex items-center gap-1 text-sm text-primary-foreground/90 hover:text-primary-foreground mb-3 absolute top-[-200px] md:top-[-260px] left-4"
          >
            <ArrowLeft className="h-4 w-4" /> Kembali
          </Link>

          <div className="bg-card rounded-3xl shadow-warm p-6 md:p-10">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <span className="inline-block px-2.5 py-1 rounded-full bg-accent text-accent-foreground text-xs font-semibold mb-3">
                  {recipe.category}
                </span>
                <h1 className="font-display text-3xl md:text-5xl font-extrabold leading-tight">
                  {recipe.title}
                </h1>
                <p className="mt-2 flex items-center gap-1.5 text-muted-foreground">
                  <MapPin className="h-4 w-4" /> {recipe.origin}
                </p>
              </div>
              <Button
                onClick={() => toggle(recipe.id)}
                variant={fav ? "default" : "outline"}
                className={cn("shrink-0", fav && "bg-primary")}
              >
                <Heart className={cn("h-4 w-4 mr-2", fav && "fill-current")} />
                {fav ? "Tersimpan" : "Simpan"}
              </Button>
            </div>

            <p className="mt-4 text-foreground/80 leading-relaxed">{recipe.description}</p>

            <div className="mt-6 grid grid-cols-3 gap-3">
              <Stat icon={<Clock className="h-4 w-4" />} label="Waktu" value={`${recipe.time} mnt`} />
              <Stat icon={<Flame className="h-4 w-4" />} label="Tingkat" value={recipe.difficulty} />
              <Stat icon={<Users className="h-4 w-4" />} label="Porsi" value={`${recipe.servings} org`} />
            </div>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="container mx-auto px-4 py-10 grid lg:grid-cols-3 gap-8 flex-1">
        <aside className="lg:col-span-1">
          <div className="bg-card rounded-2xl p-6 shadow-card sticky top-24">
            <h2 className="font-display text-xl font-bold mb-4">Bahan-bahan</h2>
            <ul className="space-y-2.5">
              {recipe.ingredients.map((ing, i) => (
                <li key={i} className="flex items-start gap-3 text-sm">
                  <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-primary shrink-0" />
                  <span>{ing}</span>
                </li>
              ))}
            </ul>
          </div>
        </aside>

        <div className="lg:col-span-2 space-y-8">
          <div>
            <h2 className="font-display text-2xl font-bold mb-4">Cara Membuat</h2>
            <ol className="space-y-4">
              {recipe.steps.map((step, i) => (
                <li
                  key={i}
                  className="flex gap-4 p-4 bg-card rounded-2xl shadow-card"
                >
                  <span className="h-9 w-9 shrink-0 rounded-full bg-gradient-warm text-primary-foreground font-bold grid place-items-center shadow-soft">
                    {i + 1}
                  </span>
                  <p className="text-foreground/90 leading-relaxed pt-1">{step}</p>
                </li>
              ))}
            </ol>
          </div>

          {recipe.tips.length > 0 && (
            <div className="bg-accent/15 border border-accent/30 rounded-2xl p-6">
              <h3 className="font-display text-lg font-bold flex items-center gap-2 mb-3">
                <Lightbulb className="h-5 w-5 text-accent" /> Tips Memasak
              </h3>
              <ul className="space-y-2 text-sm">
                {recipe.tips.map((t, i) => (
                  <li key={i} className="flex gap-2"><span>•</span>{t}</li>
                ))}
              </ul>
            </div>
          )}

          <div className="bg-secondary rounded-2xl p-6">
            <h3 className="font-display text-lg font-bold flex items-center gap-2 mb-2">
              <Apple className="h-5 w-5 text-primary" /> Catatan Nutrisi
            </h3>
            <p className="text-sm text-foreground/80">{recipe.nutrition}</p>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex flex-col items-center text-center p-3 rounded-xl bg-secondary">
      <div className="text-primary mb-1">{icon}</div>
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className="font-semibold text-sm">{value}</span>
    </div>
  );
}
