import { Link } from "react-router-dom";
import { Heart } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import RecipeCard from "@/components/RecipeCard";
import EmptyState from "@/components/EmptyState";
import { Button } from "@/components/ui/button";
import { useAllRecipes, useFavorites } from "@/hooks/useLocalRecipes";

export default function Favorites() {
  const recipes = useAllRecipes();
  const { favorites } = useFavorites();
  const saved = recipes.filter((r) => favorites.includes(r.id));

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <section className="container mx-auto px-4 py-10 flex-1">
        <div className="mb-8">
          <p className="text-xs uppercase tracking-widest text-primary font-semibold mb-1">
            Koleksi Pribadi
          </p>
          <h1 className="font-display text-3xl md:text-4xl font-extrabold">Resep Favorit Anda</h1>
        </div>

        {saved.length === 0 ? (
          <EmptyState
            icon={<Heart className="h-7 w-7" />}
            title="Belum ada favorit"
            description="Tekan ikon hati pada resep yang Anda sukai untuk menyimpannya di sini."
            action={
              <Button asChild>
                <Link to="/">Jelajahi resep</Link>
              </Button>
            }
          />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {saved.map((r) => (
              <RecipeCard key={r.id} recipe={r} />
            ))}
          </div>
        )}
      </section>
      <Footer />
    </div>
  );
}
