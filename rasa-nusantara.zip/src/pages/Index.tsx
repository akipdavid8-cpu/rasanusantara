import { useMemo, useState } from "react";
import { Search, Sparkles, ChefHat } from "lucide-react";
import Navbar from "@/components/Navbar";
import RecipeCard from "@/components/RecipeCard";
import CategoryFilter from "@/components/CategoryFilter";
import EmptyState from "@/components/EmptyState";
import { Category } from "@/data/recipes";
import { useAllRecipes } from "@/hooks/useLocalRecipes";
import heroFood from "@/assets/hero-food.jpg";
import Footer from "@/components/Footer";

const Index = () => {
  const recipes = useAllRecipes();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<Category | "all">("all");

  const featured = useMemo(() => recipes.filter((r) => r.featured).slice(0, 3), [recipes]);

  const filtered = useMemo(() => {
    return recipes.filter((r) => {
      const matchQ =
        !query ||
        r.title.toLowerCase().includes(query.toLowerCase()) ||
        r.origin.toLowerCase().includes(query.toLowerCase());
      const matchC = category === "all" || r.category === category;
      return matchQ && matchC;
    });
  }, [recipes, query, category]);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={heroFood}
            alt="Hidangan khas Indonesia"
            width={1920}
            height={1080}
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-foreground/30 via-foreground/55 to-foreground/85" />
        </div>
        <div className="relative container mx-auto px-4 py-20 md:py-32 text-center text-primary-foreground">
          <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-background/15 backdrop-blur border border-background/20 text-xs font-medium mb-5">
            <Sparkles className="h-3.5 w-3.5" />
            Warisan Kuliner Nusantara
          </span>
          <h1 className="font-display text-4xl md:text-6xl font-extrabold leading-tight max-w-3xl mx-auto">
            Temukan cita rasa <span className="text-accent">Indonesia</span> dalam setiap resep
          </h1>
          <p className="mt-5 text-base md:text-lg text-primary-foreground/90 max-w-xl mx-auto">
            Jelajahi ratusan resep otentik dari Sabang sampai Merauke — dari rendang hingga es cendol.
          </p>

          <div className="mt-8 max-w-xl mx-auto">
            <div className="flex items-center gap-2 bg-background rounded-full p-2 shadow-warm">
              <Search className="h-5 w-5 text-muted-foreground ml-3" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Cari resep, daerah... (mis. rendang)"
                className="flex-1 bg-transparent border-0 outline-none text-foreground placeholder:text-muted-foreground py-2"
                aria-label="Cari resep"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Featured */}
      {!query && category === "all" && featured.length > 0 && (
        <section className="container mx-auto px-4 py-12">
          <div className="flex items-end justify-between mb-6">
            <div>
              <p className="text-xs uppercase tracking-widest text-primary font-semibold mb-1">
                Pilihan Editor
              </p>
              <h2 className="font-display text-2xl md:text-3xl font-bold">Resep Unggulan Hari Ini</h2>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {featured.map((r) => (
              <RecipeCard key={r.id} recipe={r} />
            ))}
          </div>
        </section>
      )}

      {/* Category filter + grid */}
      <section className="container mx-auto px-4 py-8 flex-1">
        <div className="flex flex-col gap-4 mb-6">
          <h2 className="font-display text-2xl md:text-3xl font-bold">Jelajahi Kategori</h2>
          <CategoryFilter selected={category} onSelect={setCategory} />
        </div>

        {filtered.length === 0 ? (
          <EmptyState
            icon={<ChefHat className="h-7 w-7" />}
            title="Resep tidak ditemukan"
            description="Coba kata kunci lain atau pilih kategori yang berbeda."
          />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {filtered.map((r) => (
              <RecipeCard key={r.id} recipe={r} />
            ))}
          </div>
        )}
      </section>

      <Footer />
    </div>
  );
};

export default Index;
