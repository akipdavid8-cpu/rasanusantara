import rendang from "@/assets/rendang.jpg";
import nasiGoreng from "@/assets/nasi-goreng.jpg";
import sotoAyam from "@/assets/soto-ayam.jpg";
import gadoGado from "@/assets/gado-gado.jpg";
import sateAyam from "@/assets/sate-ayam.jpg";
import bakso from "@/assets/bakso.jpg";
import pempek from "@/assets/pempek.jpg";
import rawon from "@/assets/rawon.jpg";
import gudeg from "@/assets/gudeg.jpg";
import esCendol from "@/assets/es-cendol.jpg";

export type Difficulty = "Mudah" | "Sedang" | "Sulit";
export type Category = "Nasi" | "Soto" | "Sambal" | "Gorengan" | "Kue" | "Minuman" | "Daerah";

export interface Recipe {
  id: string;
  title: string;
  origin: string;
  category: Category;
  image: string;
  time: number; // minutes
  difficulty: Difficulty;
  servings: number;
  description: string;
  ingredients: string[];
  steps: string[];
  tips: string[];
  nutrition: string;
  featured?: boolean;
}

export const CATEGORIES: { value: Category; label: string; emoji: string }[] = [
  { value: "Nasi", label: "Nasi", emoji: "🍚" },
  { value: "Soto", label: "Soto", emoji: "🍲" },
  { value: "Sambal", label: "Sambal", emoji: "🌶️" },
  { value: "Gorengan", label: "Gorengan", emoji: "🍤" },
  { value: "Kue", label: "Kue", emoji: "🍰" },
  { value: "Minuman", label: "Minuman", emoji: "🥤" },
  { value: "Daerah", label: "Makanan Daerah", emoji: "🏝️" },
];

export const SAMPLE_RECIPES: Recipe[] = [
  {
    id: "rendang",
    title: "Rendang Daging",
    origin: "Padang, Sumatera Barat",
    category: "Daerah",
    image: rendang,
    time: 180,
    difficulty: "Sulit",
    servings: 6,
    description: "Rendang daging sapi khas Minang dengan bumbu rempah pekat dan santan kental yang dimasak lambat hingga kering berminyak.",
    ingredients: [
      "1 kg daging sapi, potong dadu",
      "2 liter santan dari 2 butir kelapa",
      "2 batang serai, memarkan",
      "4 lembar daun jeruk",
      "2 lembar daun kunyit",
      "15 buah cabai merah keriting",
      "8 siung bawang merah",
      "6 siung bawang putih",
      "3 cm jahe, lengkuas, kunyit",
      "Garam dan gula merah secukupnya",
    ],
    steps: [
      "Haluskan cabai, bawang merah, bawang putih, jahe, lengkuas, dan kunyit.",
      "Tumis bumbu halus bersama serai, daun jeruk, dan daun kunyit hingga harum.",
      "Masukkan daging, aduk hingga berubah warna.",
      "Tuang santan, masak dengan api kecil sambil terus diaduk.",
      "Masak 2-3 jam hingga santan mengering dan bumbu meresap, warna menjadi cokelat pekat.",
    ],
    tips: [
      "Gunakan daging bagian sengkel agar empuk.",
      "Aduk terus agar santan tidak pecah.",
      "Semakin lama dimasak, rasa semakin nikmat.",
    ],
    nutrition: "± 450 kkal per porsi · Protein tinggi · Lemak jenuh dari santan",
    featured: true,
  },
  {
    id: "nasi-goreng",
    title: "Nasi Goreng Spesial",
    origin: "Nusantara",
    category: "Nasi",
    image: nasiGoreng,
    time: 25,
    difficulty: "Mudah",
    servings: 2,
    description: "Nasi goreng dengan kecap manis, telur mata sapi, dan kerupuk — ikon kuliner Indonesia.",
    ingredients: [
      "3 piring nasi putih dingin",
      "2 butir telur",
      "100 gr ayam suwir / udang",
      "3 sdm kecap manis",
      "5 siung bawang merah",
      "3 siung bawang putih",
      "3 buah cabai rawit",
      "Garam, merica, minyak goreng",
    ],
    steps: [
      "Haluskan bawang merah, bawang putih, dan cabai.",
      "Tumis bumbu hingga harum, masukkan ayam/udang.",
      "Masukkan nasi, aduk rata dengan kecap manis.",
      "Bumbui dengan garam dan merica, aduk hingga matang merata.",
      "Sajikan dengan telur mata sapi, kerupuk, dan acar.",
    ],
    tips: [
      "Pakai nasi sehari sebelumnya agar tidak lembek.",
      "Gunakan api besar untuk aroma 'wok hei'.",
    ],
    nutrition: "± 380 kkal per porsi · Karbohidrat 55g · Protein 18g",
    featured: true,
  },
  {
    id: "soto-ayam",
    title: "Soto Ayam Lamongan",
    origin: "Lamongan, Jawa Timur",
    category: "Soto",
    image: sotoAyam,
    time: 60,
    difficulty: "Sedang",
    servings: 4,
    description: "Soto ayam kuning hangat dengan koya gurih, suwiran ayam, dan perasan jeruk nipis.",
    ingredients: [
      "1 ekor ayam kampung",
      "2 liter air",
      "6 siung bawang putih, 8 bawang merah",
      "3 cm kunyit, jahe",
      "3 batang serai, 4 daun jeruk",
      "Soun, telur rebus, kol, seledri",
      "Koya (kerupuk udang + bawang goreng)",
    ],
    steps: [
      "Rebus ayam hingga empuk, sisihkan kaldu.",
      "Haluskan bumbu, tumis hingga harum dengan serai dan daun jeruk.",
      "Masukkan bumbu ke kaldu, didihkan kembali.",
      "Suwir ayam, siapkan pelengkap.",
      "Sajikan dengan taburan koya, jeruk nipis, dan sambal.",
    ],
    tips: ["Pakai ayam kampung untuk kaldu lebih gurih.", "Koya dibuat dari kerupuk udang dihaluskan + bawang putih goreng."],
    nutrition: "± 280 kkal per porsi · Protein 22g · Rendah lemak",
    featured: true,
  },
  {
    id: "gado-gado",
    title: "Gado-Gado Jakarta",
    origin: "Jakarta",
    category: "Daerah",
    image: gadoGado,
    time: 35,
    difficulty: "Mudah",
    servings: 3,
    description: "Salad sayuran rebus disiram saus kacang gurih manis pedas — sehat dan mengenyangkan.",
    ingredients: [
      "Kacang panjang, kol, tauge, kentang, tahu, tempe, telur rebus",
      "200 gr kacang tanah goreng",
      "3 buah cabai merah",
      "2 siung bawang putih",
      "Gula merah, garam, air asam jawa",
      "Kecap manis, kerupuk",
    ],
    steps: [
      "Rebus semua sayuran hingga matang, tiriskan.",
      "Goreng tahu dan tempe.",
      "Haluskan kacang tanah, cabai, bawang putih, gula merah, garam.",
      "Tambahkan air asam jawa, encerkan dengan air matang.",
      "Tata sayur dan pelengkap, siram saus kacang, beri kerupuk.",
    ],
    tips: ["Saus kacang harus kental tapi tetap bisa disiram.", "Tambahkan emping untuk tekstur kriuk."],
    nutrition: "± 350 kkal per porsi · Serat tinggi · Protein nabati",
  },
  {
    id: "sate-ayam",
    title: "Sate Ayam Madura",
    origin: "Madura, Jawa Timur",
    category: "Daerah",
    image: sateAyam,
    time: 45,
    difficulty: "Sedang",
    servings: 4,
    description: "Sate ayam dibakar dengan bumbu kacang khas Madura yang manis gurih.",
    ingredients: [
      "500 gr daging ayam fillet, potong dadu",
      "Tusuk sate",
      "200 gr kacang tanah goreng",
      "Kecap manis, bawang merah, jeruk limau",
      "Garam, gula merah, cabai rawit",
    ],
    steps: [
      "Tusuk daging ayam pada tusuk sate.",
      "Haluskan kacang, cabai, gula merah, garam, beri sedikit air.",
      "Lumuri sate dengan sedikit bumbu kacang dan kecap.",
      "Bakar di atas bara api hingga matang sambil dibolak-balik.",
      "Sajikan dengan bumbu kacang, kecap, irisan bawang merah dan jeruk limau.",
    ],
    tips: ["Rendam tusuk sate dalam air agar tidak gosong.", "Bakar dengan arang batok untuk aroma terbaik."],
    nutrition: "± 320 kkal per porsi · Protein 28g",
    featured: true,
  },
  {
    id: "bakso",
    title: "Bakso Sapi Kuah",
    origin: "Malang, Jawa Timur",
    category: "Soto",
    image: bakso,
    time: 90,
    difficulty: "Sedang",
    servings: 5,
    description: "Bakso sapi kenyal dengan kuah kaldu bening, mie kuning, dan tauge.",
    ingredients: [
      "500 gr daging sapi giling",
      "100 gr tepung sagu/tapioka",
      "1 putih telur, es batu",
      "Bawang putih, merica, garam",
      "Tulang sapi untuk kaldu",
      "Mie kuning, bihun, sawi, tauge, seledri",
    ],
    steps: [
      "Campur daging giling, sagu, putih telur, bumbu, dan es batu hingga kalis.",
      "Bentuk bulatan, rebus hingga mengapung.",
      "Buat kaldu dari tulang sapi rebus 1 jam dengan bumbu.",
      "Siapkan mie, sawi, tauge dalam mangkuk.",
      "Tuang kuah panas, beri bakso, sambal, dan saus tomat.",
    ],
    tips: ["Es batu membuat tekstur bakso kenyal.", "Jangan terlalu banyak sagu agar tidak keras."],
    nutrition: "± 310 kkal per porsi · Protein 24g",
  },
  {
    id: "pempek",
    title: "Pempek Palembang",
    origin: "Palembang, Sumatera Selatan",
    category: "Gorengan",
    image: pempek,
    time: 75,
    difficulty: "Sedang",
    servings: 4,
    description: "Pempek ikan tenggiri kenyal disajikan dengan cuko hitam manis asam pedas.",
    ingredients: [
      "500 gr ikan tenggiri giling",
      "300 gr tepung sagu",
      "200 ml air es, garam, kaldu bubuk",
      "Cuko: gula merah, asam jawa, bawang putih, cabai rawit, ebi",
    ],
    steps: [
      "Campur ikan giling, air es, garam, kaldu hingga rata.",
      "Tambahkan tepung sagu sedikit demi sedikit, jangan diuleni.",
      "Bentuk lonjong/bulat, rebus hingga mengapung.",
      "Goreng pempek hingga keemasan.",
      "Masak cuko: rebus gula merah, asam, bawang putih halus, cabai hingga mengental.",
    ],
    tips: ["Adonan jangan diuleni agar tidak keras.", "Cuko terbaik istirahat semalam sebelum disajikan."],
    nutrition: "± 290 kkal per porsi · Omega-3 tinggi",
  },
  {
    id: "rawon",
    title: "Rawon Daging",
    origin: "Surabaya, Jawa Timur",
    category: "Daerah",
    image: rawon,
    time: 120,
    difficulty: "Sedang",
    servings: 6,
    description: "Sup daging berkuah hitam khas Jawa Timur dari kluwek, disajikan dengan nasi dan tauge pendek.",
    ingredients: [
      "750 gr daging sapi sandung lamur",
      "4 buah kluwek, ambil isinya",
      "8 bawang merah, 5 bawang putih",
      "3 buah kemiri, 2 cm kunyit, jahe",
      "Serai, daun jeruk, daun salam, lengkuas",
      "Tauge pendek, telur asin, sambal",
    ],
    steps: [
      "Rebus daging hingga empuk, potong dadu, sisihkan kaldu.",
      "Haluskan bumbu termasuk kluwek.",
      "Tumis bumbu dengan serai dan daun-daunan hingga harum.",
      "Masukkan bumbu ke kaldu, masukkan daging.",
      "Masak hingga bumbu meresap, sajikan dengan nasi, tauge, telur asin.",
    ],
    tips: ["Pilih kluwek yang tidak pahit (cicipi sedikit).", "Rawon lebih nikmat dipanaskan ulang."],
    nutrition: "± 380 kkal per porsi · Zat besi tinggi",
  },
  {
    id: "gudeg",
    title: "Gudeg Yogya",
    origin: "Yogyakarta",
    category: "Daerah",
    image: gudeg,
    time: 240,
    difficulty: "Sulit",
    servings: 6,
    description: "Nangka muda dimasak lama dengan santan dan gula jawa, disajikan dengan ayam, telur, dan krecek.",
    ingredients: [
      "1 kg nangka muda, potong",
      "1 liter santan kental",
      "200 gr gula merah",
      "Daun salam, lengkuas, daun jati (opsional)",
      "Bawang merah, putih, kemiri, ketumbar",
      "Ayam kampung, telur rebus, krecek",
    ],
    steps: [
      "Rebus nangka muda 30 menit, tiriskan.",
      "Haluskan bumbu, tumis hingga harum.",
      "Susun nangka, bumbu, gula merah dalam panci besar.",
      "Tuang santan, masak api kecil 4 jam hingga kuah mengering.",
      "Sajikan dengan ayam areh, telur, sambal krecek.",
    ],
    tips: ["Daun jati memberi warna cokelat alami.", "Masak dalam panci tanah liat untuk rasa otentik."],
    nutrition: "± 420 kkal per porsi · Serat dan vitamin C",
  },
  {
    id: "es-cendol",
    title: "Es Cendol Dawet",
    origin: "Jawa Barat",
    category: "Minuman",
    image: esCendol,
    time: 30,
    difficulty: "Mudah",
    servings: 4,
    description: "Minuman segar dengan cendol hijau pandan, santan, dan gula merah cair — pelepas dahaga sempurna.",
    ingredients: [
      "100 gr tepung beras",
      "50 gr tepung sagu",
      "500 ml air daun pandan & suji",
      "400 ml santan kental, garam",
      "200 gr gula merah, daun pandan",
      "Es batu serut",
    ],
    steps: [
      "Masak tepung dan air pandan hingga kental.",
      "Cetak adonan melalui saringan cendol ke air es agar berbentuk butiran.",
      "Rebus santan dengan garam dan daun pandan, dinginkan.",
      "Rebus gula merah dengan sedikit air hingga larut, saring.",
      "Sajikan cendol dengan santan, sirup gula merah, dan es serut.",
    ],
    tips: ["Pakai pewarna alami daun suji untuk hijau natural.", "Sajikan sangat dingin."],
    nutrition: "± 220 kkal per porsi · Sumber energi cepat",
    featured: true,
  },
];
