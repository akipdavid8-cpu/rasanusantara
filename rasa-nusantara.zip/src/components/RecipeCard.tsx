import { Link } from "react-router-dom";
import { Heart, Clock, MapPin, Flame } from "lucide-react";
import { Recipe } from "@/data/recipes";
import { useFavorites } from "@/hooks/useLocalRecipes";
import { cn } from "@/lib/utils";

interface Props {
  recipe: Recipe;
}

export default function RecipeCard({ recipe }: Props) {
  const { isFavorite, toggle } = useFavorites();
  const fav = isFavorite(recipe.id);

  return (
    <Link
      to={`/recipe/${recipe.id}`}
      className="group relative flex flex-col overflow-hidden rounded-2xl bg-card shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-warm"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={recipe.image}
          alt={recipe.title}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <button
          aria-label={fav ? "Hapus dari favorit" : "Simpan ke favorit"}
          onClick={(e) => {
            e.preventDefault();
            toggle(recipe.id);
          }}
          className="absolute top-3 right-3 h-9 w-9 grid place-items-center rounded-full bg-background/90 backdrop-blur shadow-soft transition-transform hover:scale-110"
        >
          <Heart className={cn("h-4 w-4", fav ? "fill-primary text-primary" : "text-foreground/70")} />
        </button>
        <span className="absolute top-3 left-3 inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-accent text-accent-foreground text-xs font-semibold shadow-soft">
          {recipe.category}
        </span>
      </div>

      <div className="flex flex-col gap-2 p-4">
        <h3 className="font-display text-lg font-bold leading-tight line-clamp-2">{recipe.title}</h3>
        <p className="flex items-center gap-1 text-xs text-muted-foreground">
          <MapPin className="h-3 w-3" /> {recipe.origin}
        </p>
        <div className="mt-2 flex items-center justify-between text-xs text-foreground/70">
          <span className="inline-flex items-center gap-1">
            <Clock className="h-3.5 w-3.5 text-primary" /> {recipe.time} mnt
          </span>
          <span className="inline-flex items-center gap-1">
            <Flame className="h-3.5 w-3.5 text-accent" /> {recipe.difficulty}
          </span>
        </div>
      </div>
    </Link>
  );
}
