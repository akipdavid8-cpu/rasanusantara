import { ReactNode } from "react";
import { UtensilsCrossed } from "lucide-react";

interface Props {
  title: string;
  description?: string;
  icon?: ReactNode;
  action?: ReactNode;
}

export default function EmptyState({ title, description, icon, action }: Props) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-16 px-6 rounded-2xl border border-dashed border-border bg-card/50">
      <div className="h-16 w-16 rounded-2xl bg-secondary grid place-items-center mb-4 text-muted-foreground">
        {icon ?? <UtensilsCrossed className="h-7 w-7" />}
      </div>
      <h3 className="font-display text-xl font-bold mb-1">{title}</h3>
      {description && <p className="text-sm text-muted-foreground max-w-md">{description}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}
