import { UtensilsCrossed } from "lucide-react";

export default function Footer() {
  return (
    <footer className="border-t border-border bg-secondary/40 mt-12">
      <div className="container mx-auto px-4 py-10 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-lg bg-gradient-warm grid place-items-center">
            <UtensilsCrossed className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="font-display font-bold">Rasa Nusantara</span>
        </div>
        <p className="text-xs text-muted-foreground text-center">
          © {new Date().getFullYear()} Rasa Nusantara · Dibuat dengan ❤️ untuk pecinta kuliner Indonesia
        </p>
      </div>
    </footer>
  );
}
