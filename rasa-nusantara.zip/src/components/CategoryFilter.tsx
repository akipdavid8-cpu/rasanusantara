import { CATEGORIES, Category } from "@/data/recipes";
import { cn } from "@/lib/utils";

interface Props {
  selected: Category | "all";
  onSelect: (c: Category | "all") => void;
}

export default function CategoryFilter({ selected, onSelect }: Props) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-thin">
      <button
        onClick={() => onSelect("all")}
        className={cn(
          "shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-all",
          selected === "all"
            ? "bg-primary text-primary-foreground shadow-soft"
            : "bg-secondary text-secondary-foreground hover:bg-secondary/70"
        )}
      >
        ✨ Semua
      </button>
      {CATEGORIES.map((c) => (
        <button
          key={c.value}
          onClick={() => onSelect(c.value)}
          className={cn(
            "shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-all",
            selected === c.value
              ? "bg-primary text-primary-foreground shadow-soft"
              : "bg-secondary text-secondary-foreground hover:bg-secondary/70"
          )}
        >
          <span className="mr-1">{c.emoji}</span>
          {c.label}
        </button>
      ))}
    </div>
  );
}
