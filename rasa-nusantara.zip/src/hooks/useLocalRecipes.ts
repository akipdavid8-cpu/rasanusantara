import { useEffect, useState, useCallback } from "react";
import { Recipe, SAMPLE_RECIPES } from "@/data/recipes";

const FAV_KEY = "rasa-nusantara:favorites";
const USER_KEY = "rasa-nusantara:user-recipes";

function read<T>(key: string, fallback: T): T {
  try {
    const v = localStorage.getItem(key);
    return v ? (JSON.parse(v) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function useFavorites() {
  const [favorites, setFavorites] = useState<string[]>(() => read(FAV_KEY, []));

  useEffect(() => {
    localStorage.setItem(FAV_KEY, JSON.stringify(favorites));
  }, [favorites]);

  const toggle = useCallback((id: string) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  }, []);

  const isFavorite = useCallback((id: string) => favorites.includes(id), [favorites]);

  return { favorites, toggle, isFavorite };
}

export function useUserRecipes() {
  const [userRecipes, setUserRecipes] = useState<Recipe[]>(() => read(USER_KEY, []));

  useEffect(() => {
    localStorage.setItem(USER_KEY, JSON.stringify(userRecipes));
  }, [userRecipes]);

  const add = useCallback((recipe: Recipe) => {
    setUserRecipes((prev) => [recipe, ...prev]);
  }, []);

  return { userRecipes, add };
}

export function useAllRecipes(): Recipe[] {
  const { userRecipes } = useUserRecipes();
  return [...userRecipes, ...SAMPLE_RECIPES];
}
